mod compiler;
mod lexer;
mod vm;
mod worker;

use std::{env, fs, process, time::Instant};
use worker::{Priority, WorkerPool};

fn usage() {
    eprintln!("Nexa v0.2.0\nUsage: nexa run <file.nx>\n       nexa worker-demo [workers] [tasks]\n       nexa help");
}

fn run_worker_demo(args: &[String]) -> Result<(), String> {
    let workers = parse_arg(args.get(2), 4, "worker count")?;
    let tasks = parse_arg(args.get(3), 10_000, "task count")?;
    if tasks == 0 { return Err("task count must be greater than zero".into()); }

    let pool = WorkerPool::new(workers);
    let start = Instant::now();
    let mut results = Vec::with_capacity(tasks);
    for n in 0..tasks {
        let priority = if n % 10 == 0 { Priority::High } else { Priority::Normal };
        results.push(pool.submit_with_priority(priority, move || n as u64 * n as u64));
    }
    let checksum: u64 = results
        .into_iter()
        .map(|rx| rx.recv().map_err(|e| format!("worker result channel closed: {e}")))
        .collect::<Result<Vec<_>, _>>()?
        .into_iter()
        .sum();
    pool.wait_idle();
    let elapsed = start.elapsed();
    let stats = pool.stats();

    println!("Nexa worker demo");
    println!("workers:   {}", stats.workers);
    println!("tasks:     {}", stats.submitted);
    println!("completed: {}", stats.completed);
    println!("pending:   {}", stats.pending);
    println!("checksum:  {checksum}");
    println!("elapsed:   {:.3} ms", elapsed.as_secs_f64() * 1_000.0);
    if elapsed.as_secs_f64() > 0.0 {
        println!("throughput: {:.0} tasks/sec", tasks as f64 / elapsed.as_secs_f64());
    }
    Ok(())
}

fn parse_arg(value: Option<&String>, default: usize, label: &str) -> Result<usize, String> {
    match value {
        Some(raw) => raw.parse().map_err(|_| format!("invalid {label}: {raw}")),
        None => Ok(default),
    }
}

fn main() {
    let args: Vec<String> = env::args().collect();
    match args.get(1).map(String::as_str) {
        Some("run") => {
            let Some(path) = args.get(2) else { usage(); process::exit(2); };
            let source = match fs::read_to_string(path) {
                Ok(s) => s,
                Err(e) => { eprintln!("nexa: cannot read '{path}': {e}"); process::exit(1); }
            };
            let program = match compiler::compile(&source) {
                Ok(p) => p,
                Err(e) => { eprintln!("compile error: {e}"); process::exit(1); }
            };
            if let Err(e) = vm::execute(&program) {
                eprintln!("runtime error: {e}");
                process::exit(1);
            }
        }
        Some("worker-demo") => {
            if let Err(error) = run_worker_demo(&args) {
                eprintln!("worker error: {error}");
                process::exit(1);
            }
        }
        Some("help") | None => usage(),
        Some(other) => { eprintln!("unknown command: {other}"); usage(); process::exit(2); }
    }
}
