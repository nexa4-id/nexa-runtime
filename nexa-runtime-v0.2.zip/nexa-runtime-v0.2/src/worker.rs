//! Nexa v0.2 worker scheduler.
//!
//! This is a safe, std-only work-stealing prototype. External submissions are
//! distributed across per-worker queues. An idle worker steals from the back
//! of another worker's queue while the owning worker consumes from the front.

use std::collections::VecDeque;
use std::panic::{catch_unwind, AssertUnwindSafe};
use std::sync::atomic::{AtomicBool, AtomicU64, AtomicUsize, Ordering};
use std::sync::{mpsc, Arc, Condvar, Mutex};
use std::thread::{self, JoinHandle};
use std::time::Duration;

type Task = Box<dyn FnOnce() + Send + 'static>;

const PRIORITY_LEVELS: usize = 3;
const IDLE_WAIT: Duration = Duration::from_millis(100);

/// Task priority. Higher-priority work is selected first within each queue.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum Priority {
    High,
    Normal,
    Low,
}

impl Priority {
    fn index(self) -> usize {
        match self {
            Self::High => 0,
            Self::Normal => 1,
            Self::Low => 2,
        }
    }
}

#[derive(Default)]
struct Queues {
    levels: [VecDeque<Task>; PRIORITY_LEVELS],
}

impl Queues {
    fn push(&mut self, priority: Priority, task: Task) {
        self.levels[priority.index()].push_back(task);
    }

    fn pop_front(&mut self) -> Option<Task> {
        self.levels.iter_mut().find_map(VecDeque::pop_front)
    }

    fn steal_back(&mut self) -> Option<Task> {
        self.levels.iter_mut().find_map(VecDeque::pop_back)
    }

}

struct Shared {
    injector: Mutex<Queues>,
    locals: Vec<Mutex<Queues>>,
    wake_lock: Mutex<()>,
    wake: Condvar,
    wake_generation: AtomicU64,
    shutdown: AtomicBool,
    pending: AtomicUsize,
    submitted: AtomicU64,
    completed: AtomicU64,
    next_queue: AtomicUsize,
}

/// A reusable worker pool with per-worker queues and work stealing.
pub struct WorkerPool {
    shared: Arc<Shared>,
    threads: Vec<JoinHandle<()>>,
}

#[derive(Debug, Clone, Copy)]
pub struct WorkerStats {
    pub workers: usize,
    pub pending: usize,
    pub submitted: u64,
    pub completed: u64,
}

impl WorkerPool {
    /// Creates a pool. A zero worker count is clamped to one.
    pub fn new(worker_count: usize) -> Self {
        let count = worker_count.max(1);
        let shared = Arc::new(Shared {
            injector: Mutex::new(Queues::default()),
            locals: (0..count).map(|_| Mutex::new(Queues::default())).collect(),
            wake_lock: Mutex::new(()),
            wake: Condvar::new(),
            wake_generation: AtomicU64::new(0),
            shutdown: AtomicBool::new(false),
            pending: AtomicUsize::new(0),
            submitted: AtomicU64::new(0),
            completed: AtomicU64::new(0),
            next_queue: AtomicUsize::new(0),
        });

        let mut threads = Vec::with_capacity(count);
        for worker_id in 0..count {
            let worker_shared = Arc::clone(&shared);
            let handle = thread::Builder::new()
                .name(format!("nexa-worker-{worker_id}"))
                .spawn(move || worker_loop(worker_id, worker_shared))
                .expect("failed to spawn Nexa worker thread");
            threads.push(handle);
        }

        Self { shared, threads }
    }

    /// Submits normal-priority work and returns a receiver for its result.
    pub fn submit<F, T>(&self, job: F) -> mpsc::Receiver<T>
    where
        F: FnOnce() -> T + Send + 'static,
        T: Send + 'static,
    {
        self.submit_with_priority(Priority::Normal, job)
    }

    /// Submits work with an explicit priority.
    pub fn submit_with_priority<F, T>(&self, priority: Priority, job: F) -> mpsc::Receiver<T>
    where
        F: FnOnce() -> T + Send + 'static,
        T: Send + 'static,
    {
        assert!(
            !self.shared.shutdown.load(Ordering::Acquire),
            "cannot submit to a stopped Nexa worker pool"
        );

        let (tx, rx) = mpsc::channel();
        let task: Task = Box::new(move || {
            // A panic is contained so it cannot kill a worker thread. The
            // receiver observes disconnection if the submitted closure panics.
            let result = catch_unwind(AssertUnwindSafe(job));
            if let Ok(value) = result {
                let _ = tx.send(value);
            }
        });

        self.shared.pending.fetch_add(1, Ordering::AcqRel);
        self.shared.submitted.fetch_add(1, Ordering::Relaxed);

        // Round-robin placement avoids funneling all submissions through one
        // worker queue. Idle workers may steal from the back of these queues.
        let queue_id = self.shared.next_queue.fetch_add(1, Ordering::Relaxed)
            % self.shared.locals.len();
        self.shared.locals[queue_id]
            .lock()
            .expect("Nexa local queue mutex poisoned")
            .push(priority, task);

        self.notify_one();
        rx
    }

    /// Number of worker threads in this pool.
    pub fn size(&self) -> usize {
        self.threads.len()
    }

    /// Blocks until all submitted tasks have completed.
    pub fn wait_idle(&self) {
        let mut guard = self.shared.wake_lock.lock().expect("Nexa wake mutex poisoned");
        while self.shared.pending.load(Ordering::Acquire) != 0 {
            guard = self.shared.wake.wait(guard).expect("Nexa wake mutex poisoned");
        }
    }

    /// Returns a snapshot of scheduler counters.
    pub fn stats(&self) -> WorkerStats {
        WorkerStats {
            workers: self.size(),
            pending: self.shared.pending.load(Ordering::Acquire),
            submitted: self.shared.submitted.load(Ordering::Relaxed),
            completed: self.shared.completed.load(Ordering::Relaxed),
        }
    }

    fn notify_one(&self) {
        // Pairing the notification with this mutex prevents a missed wakeup
        // between a worker's final queue check and its condition-variable wait.
        let _guard = self.shared.wake_lock.lock().expect("Nexa wake mutex poisoned");
        self.shared.wake_generation.fetch_add(1, Ordering::Release);
        self.shared.wake.notify_one();
    }
}

fn worker_loop(worker_id: usize, shared: Arc<Shared>) {
    loop {
        let observed_generation = shared.wake_generation.load(Ordering::Acquire);
        if let Some(task) = take_task(worker_id, &shared) {
            let _ = catch_unwind(AssertUnwindSafe(task));
            shared.pending.fetch_sub(1, Ordering::AcqRel);
            shared.completed.fetch_add(1, Ordering::Relaxed);
            {
                let _guard = shared.wake_lock.lock().expect("Nexa wake mutex poisoned");
                shared.wake.notify_all();
            }
            continue;
        }

        if shared.shutdown.load(Ordering::Acquire)
            && shared.pending.load(Ordering::Acquire) == 0
        {
            return;
        }

        let guard = shared.wake_lock.lock().expect("Nexa wake mutex poisoned");
        // A generation counter avoids missed notifications without taking
        // queue locks while holding the wake mutex (which would invert locks).
        if shared.wake_generation.load(Ordering::Acquire) != observed_generation {
            drop(guard);
            continue;
        }
        let _ = shared.wake.wait_timeout(guard, IDLE_WAIT)
            .expect("Nexa wake mutex poisoned");
    }
}

fn take_task(worker_id: usize, shared: &Shared) -> Option<Task> {
    if let Some(task) = shared.locals[worker_id]
        .lock()
        .expect("Nexa local queue mutex poisoned")
        .pop_front()
    {
        return Some(task);
    }

    if let Some(task) = shared
        .injector
        .lock()
        .expect("Nexa injector mutex poisoned")
        .pop_front()
    {
        return Some(task);
    }

    let count = shared.locals.len();
    for offset in 1..count {
        let victim = (worker_id + offset) % count;
        if let Some(task) = shared.locals[victim]
            .lock()
            .expect("Nexa local queue mutex poisoned")
            .steal_back()
        {
            return Some(task);
        }
    }
    None
}

impl Drop for WorkerPool {
    fn drop(&mut self) {
        self.shared.shutdown.store(true, Ordering::Release);
        {
            let _guard = self.shared.wake_lock.lock().expect("Nexa wake mutex poisoned");
            self.shared.wake.notify_all();
        }
        for handle in self.threads.drain(..) {
            let _ = handle.join();
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::sync::atomic::{AtomicUsize, Ordering};

    #[test]
    fn executes_many_jobs_on_reusable_pool() {
        let pool = WorkerPool::new(4);
        let results: Vec<_> = (0..1_000).map(|n| pool.submit(move || n * n)).collect();
        let total: usize = results.into_iter().map(|r| r.recv().unwrap()).sum();
        pool.wait_idle();
        assert_eq!(total, (0..1_000).map(|n| n * n).sum());
        assert_eq!(pool.size(), 4);
        assert_eq!(pool.stats().completed, 1_000);
    }

    #[test]
    fn clamps_zero_workers_to_one() {
        assert_eq!(WorkerPool::new(0).size(), 1);
    }

    #[test]
    fn supports_priorities() {
        let pool = WorkerPool::new(1);
        let low = pool.submit_with_priority(Priority::Low, || 1);
        let high = pool.submit_with_priority(Priority::High, || 2);
        assert!(matches!(low.recv(), Ok(1)));
        assert!(matches!(high.recv(), Ok(2)));
    }

    #[test]
    fn worker_survives_a_panicking_task() {
        let pool = WorkerPool::new(1);
        let panic_result = pool.submit(|| -> usize { panic!("intentional test panic") });
        assert!(panic_result.recv().is_err());
        assert_eq!(pool.submit(|| 42).recv().unwrap(), 42);
    }

    #[test]
    fn work_is_processed_by_multiple_threads() {
        let pool = WorkerPool::new(4);
        let threads = Arc::new(Mutex::new(std::collections::HashSet::new()));
        let mut receivers = Vec::new();
        for _ in 0..200 {
            let seen = Arc::clone(&threads);
            receivers.push(pool.submit(move || {
                seen.lock().unwrap().insert(thread::current().id());
            }));
        }
        for receiver in receivers { receiver.recv().unwrap(); }
        pool.wait_idle();
        // Scheduling may legitimately use fewer than all workers for tiny
        // tasks, so assert reuse and completion rather than exact distribution.
        assert!(pool.stats().completed >= 200);
        assert!(!threads.lock().unwrap().is_empty());
    }

    #[test]
    fn reports_pending_and_completed_counts() {
        let pool = WorkerPool::new(2);
        let counter = Arc::new(AtomicUsize::new(0));
        let jobs: Vec<_> = (0..20).map(|_| {
            let counter = Arc::clone(&counter);
            pool.submit(move || counter.fetch_add(1, Ordering::Relaxed))
        }).collect();
        for job in jobs { job.recv().unwrap(); }
        pool.wait_idle();
        assert_eq!(counter.load(Ordering::Relaxed), 20);
        assert_eq!(pool.stats().submitted, 20);
        assert_eq!(pool.stats().completed, 20);
        assert_eq!(pool.stats().pending, 0);
    }
}
