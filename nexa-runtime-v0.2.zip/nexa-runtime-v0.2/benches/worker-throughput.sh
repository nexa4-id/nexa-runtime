#!/usr/bin/env sh
set -eu

cargo build --release
for workers in 1 2 4 8; do
  echo "===== workers=${workers} tasks=100000 ====="
  ./target/release/nexa worker-demo "$workers" 100000
done
