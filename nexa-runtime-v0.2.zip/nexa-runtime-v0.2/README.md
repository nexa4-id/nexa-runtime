# Nexa Runtime

A Rust-built, Rust-inspired programming language and bytecode runtime. Nexa's
current development priority is a reusable worker engine with per-worker
queues, task priorities, and work stealing.

## Status

**v0.2.0 — worker scheduler prototype.** This is an early development build,
not production-ready. The scheduler uses safe Rust and only the standard
library. Its per-worker queues are individually mutex-protected; this is a
correctness-first baseline, not a lock-free scheduler.

## Build

Install the stable Rust toolchain from <https://rustup.rs>, then:

```sh
cargo build --release
cargo test
```

## Run a Nexa program

```sh
cargo run --release -- run examples/hello.nx
```

## Run the worker demonstration

```sh
cargo run --release -- worker-demo
cargo run --release -- worker-demo 8 100000
```

Arguments are worker count and task count. The demo reports elapsed time,
throughput, task counters, and a checksum. Compare results only on the same
machine with equivalent workloads; this demo is not a substitute for a
controlled benchmark against Node.js, Deno, or Bun.

## Worker API (Rust host API)

```rust
use nexa::worker::{Priority, WorkerPool};

let pool = WorkerPool::new(4);
let result = pool.submit_with_priority(Priority::High, || 6 * 7);
assert_eq!(result.recv().unwrap(), 42);
```

The v0.2 scheduler distributes submissions across worker-local queues. A
worker consumes from the front of its own queue and steals from the back of
other queues when idle. `Drop` shuts down the pool and joins worker threads
after queued work is drained. A panic inside a task is contained so the worker
thread remains alive; the task's result receiver is disconnected.

## Current limitations

- The `.nx` language does not yet expose worker creation or task submission.
- The VM is still a small single-threaded integer bytecode interpreter.
- Task priority is best-effort queue ordering, not a hard real-time guarantee.
- No cancellation, async/await, I/O reactor, or lock-free queue yet.
- The worker scheduler has not yet been compiled or benchmarked in this
  environment; run the commands above to verify it on your platform.

## License

MIT. See [LICENSE](LICENSE).
