use crate::compiler::{Op, Program};

pub fn execute(program: &Program) -> Result<(), String> {
    let mut stack: Vec<i64> = Vec::with_capacity(64);
    let mut locals = vec![0i64; program.local_count];
    let mut ip = 0usize;
    loop {
        let op = program.code.get(ip).ok_or_else(|| "instruction pointer out of bounds".to_string())?;
        ip += 1;
        match op {
            Op::Push(n) => stack.push(*n),
            Op::Load(slot) => stack.push(*locals.get(*slot as usize).ok_or("invalid local slot")?),
            Op::Store(slot) => {
                let value = stack.pop().ok_or("stack underflow on STORE")?;
                *locals.get_mut(*slot as usize).ok_or("invalid local slot")? = value;
            }
            Op::Add => binary(&mut stack, i64::checked_add, "addition overflow")?,
            Op::Sub => binary(&mut stack, i64::checked_sub, "subtraction overflow")?,
            Op::Mul => binary(&mut stack, i64::checked_mul, "multiplication overflow")?,
            Op::Div => {
                let b = stack.pop().ok_or("stack underflow on DIV")?;
                let a = stack.pop().ok_or("stack underflow on DIV")?;
                if b == 0 { return Err("division by zero".into()); }
                stack.push(a.checked_div(b).ok_or("division overflow")?);
            }
            Op::Print => println!("{}", stack.pop().ok_or("stack underflow on PRINT")?),
            Op::Halt => return Ok(()),
        }
    }
}

fn binary<F>(stack: &mut Vec<i64>, f: F, message: &str) -> Result<(), String>
where F: FnOnce(i64, i64) -> Option<i64> {
    let b = stack.pop().ok_or("stack underflow")?;
    let a = stack.pop().ok_or("stack underflow")?;
    stack.push(f(a, b).ok_or_else(|| message.to_string())?);
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::compiler::compile;
    #[test]
    fn runs_arithmetic_without_runtime_error() {
        let p = compile("fn main() { let answer = (10 + 2) * 3; print(answer); }").unwrap();
        assert!(execute(&p).is_ok());
    }
    #[test]
    fn catches_division_by_zero() {
        let p = compile("fn main() { print(10 / 0); }").unwrap();
        assert_eq!(execute(&p).unwrap_err(), "division by zero");
    }
}
