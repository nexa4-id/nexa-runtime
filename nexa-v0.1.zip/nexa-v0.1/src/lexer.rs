#[derive(Debug, Clone, PartialEq)]
pub enum TokenKind {
    Fn, Main, Let, Print, Ident(String), Int(i64),
    LParen, RParen, LBrace, RBrace, Colon, Semi, Comma,
    Assign, Plus, Minus, Star, Slash, Eof,
}

#[derive(Debug, Clone)]
pub struct Token {
    pub kind: TokenKind,
    pub line: usize,
    pub column: usize,
}

pub fn tokenize(source: &str) -> Result<Vec<Token>, String> {
    let chars: Vec<char> = source.chars().collect();
    let (mut i, mut line, mut col) = (0usize, 1usize, 1usize);
    let mut out = Vec::new();
    while i < chars.len() {
        let c = chars[i];
        if c == '\n' { line += 1; col = 1; i += 1; continue; }
        if c.is_whitespace() { col += 1; i += 1; continue; }
        if c == '/' && chars.get(i + 1) == Some(&'/') {
            while i < chars.len() && chars[i] != '\n' { i += 1; col += 1; }
            continue;
        }
        let start_col = col;
        if c.is_ascii_digit() {
            let start = i;
            while i < chars.len() && chars[i].is_ascii_digit() { i += 1; col += 1; }
            let text: String = chars[start..i].iter().collect();
            let value = text.parse::<i64>().map_err(|_| format!("integer out of range at {line}:{start_col}"))?;
            out.push(Token { kind: TokenKind::Int(value), line, column: start_col });
            continue;
        }
        if c.is_ascii_alphabetic() || c == '_' {
            let start = i;
            while i < chars.len() && (chars[i].is_ascii_alphanumeric() || chars[i] == '_') { i += 1; col += 1; }
            let word: String = chars[start..i].iter().collect();
            let kind = match word.as_str() {
                "fn" => TokenKind::Fn, "main" => TokenKind::Main,
                "let" => TokenKind::Let, "print" => TokenKind::Print,
                _ => TokenKind::Ident(word),
            };
            out.push(Token { kind, line, column: start_col });
            continue;
        }
        let kind = match c {
            '(' => TokenKind::LParen, ')' => TokenKind::RParen,
            '{' => TokenKind::LBrace, '}' => TokenKind::RBrace,
            ':' => TokenKind::Colon, ';' => TokenKind::Semi, ',' => TokenKind::Comma,
            '=' => TokenKind::Assign, '+' => TokenKind::Plus, '-' => TokenKind::Minus,
            '*' => TokenKind::Star, '/' => TokenKind::Slash,
            _ => return Err(format!("unexpected character '{c}' at {line}:{col}")),
        };
        out.push(Token { kind, line, column: col });
        i += 1; col += 1;
    }
    out.push(Token { kind: TokenKind::Eof, line, column: col });
    Ok(out)
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn tokenizes_keywords_and_numbers() {
        let tokens = tokenize("fn main() { let x = 42; }").unwrap();
        assert_eq!(tokens[0].kind, TokenKind::Fn);
        assert_eq!(tokens[1].kind, TokenKind::Main);
        assert_eq!(tokens[8].kind, TokenKind::Int(42));
    }
}
