use std::collections::HashMap;
use crate::lexer::{tokenize, Token, TokenKind};

#[derive(Debug, Clone)]
pub enum Op { Push(i64), Load(u16), Store(u16), Add, Sub, Mul, Div, Print, Halt }
#[derive(Debug, Clone)]
pub struct Program { pub code: Vec<Op>, pub local_count: usize }

struct Parser { tokens: Vec<Token>, pos: usize, code: Vec<Op>, locals: HashMap<String, u16>, next_local: usize }

impl Parser {
    fn current(&self) -> &Token { &self.tokens[self.pos] }
    fn advance(&mut self) -> Token { let t = self.tokens[self.pos].clone(); if !matches!(t.kind, TokenKind::Eof) { self.pos += 1; } t }
    fn error(&self, message: &str) -> String { format!("{message} at {}:{}", self.current().line, self.current().column) }
    fn eat(&mut self, expected: TokenKind, message: &str) -> Result<(), String> {
        if self.current().kind == expected { self.advance(); Ok(()) } else { Err(self.error(message)) }
    }
    fn parse_program(&mut self) -> Result<Program, String> {
        self.eat(TokenKind::Fn, "expected 'fn'")?;
        self.eat(TokenKind::Main, "expected 'main'")?;
        self.eat(TokenKind::LParen, "expected '('")?;
        self.eat(TokenKind::RParen, "expected ')'")?;
        self.eat(TokenKind::LBrace, "expected '{'")?;
        while self.current().kind != TokenKind::RBrace && self.current().kind != TokenKind::Eof { self.statement()?; }
        self.eat(TokenKind::RBrace, "expected '}'")?;
        if self.current().kind != TokenKind::Eof { return Err(self.error("unexpected tokens after main")); }
        self.code.push(Op::Halt);
        Ok(Program { code: self.code.clone(), local_count: self.next_local })
    }
    fn statement(&mut self) -> Result<(), String> {
        match self.current().kind {
            TokenKind::Let => {
                self.advance();
                let name = match self.advance().kind { TokenKind::Ident(n) => n, _ => return Err(self.error("expected variable name")) };
                if self.current().kind == TokenKind::Colon {
                    self.advance();
                    match self.advance().kind { TokenKind::Ident(t) if t == "i64" => {}, _ => return Err(self.error("only the i64 type is supported in v0.1")) }
                }
                self.eat(TokenKind::Assign, "expected '='")?;
                self.expression(0)?;
                self.eat(TokenKind::Semi, "expected ';'")?;
                if self.locals.contains_key(&name) { return Err(self.error("variable already declared")); }
                let slot = u16::try_from(self.next_local).map_err(|_| self.error("too many local variables"))?;
                self.next_local += 1;
                self.locals.insert(name, slot);
                self.code.push(Op::Store(slot));
                Ok(())
            }
            TokenKind::Print => {
                self.advance(); self.eat(TokenKind::LParen, "expected '(' after print")?;
                self.expression(0)?;
                self.eat(TokenKind::RParen, "expected ')' after print expression")?;
                self.eat(TokenKind::Semi, "expected ';'")?;
                self.code.push(Op::Print); Ok(())
            }
            _ => Err(self.error("expected 'let' or 'print' statement")),
        }
    }
    fn expression(&mut self, min_bp: u8) -> Result<(), String> {
        match self.advance().kind {
            TokenKind::Int(n) => self.code.push(Op::Push(n)),
            TokenKind::Ident(name) => {
                let slot = *self.locals.get(&name).ok_or_else(|| self.error(&format!("unknown variable '{name}'")))?;
                self.code.push(Op::Load(slot));
            }
            TokenKind::Minus => { self.expression(5)?; self.code.push(Op::Push(-1)); self.code.push(Op::Mul); }
            TokenKind::LParen => { self.expression(0)?; self.eat(TokenKind::RParen, "expected ')'")?; }
            _ => return Err(self.error("expected integer, variable, or parenthesized expression")),
        }
        loop {
            let (left_bp, right_bp, op) = match self.current().kind {
                TokenKind::Plus => (1, 2, Op::Add), TokenKind::Minus => (1, 2, Op::Sub),
                TokenKind::Star => (3, 4, Op::Mul), TokenKind::Slash => (3, 4, Op::Div),
                _ => break,
            };
            if left_bp < min_bp { break; }
            self.advance(); self.expression(right_bp)?; self.code.push(op);
        }
        Ok(())
    }
}

pub fn compile(source: &str) -> Result<Program, String> {
    let tokens = tokenize(source)?;
    let mut parser = Parser { tokens, pos: 0, code: Vec::new(), locals: HashMap::new(), next_local: 0 };
    parser.parse_program()
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn compiles_simple_program() {
        let p = compile("fn main() { let x: i64 = 2 + 3 * 4; print(x); }").unwrap();
        assert_eq!(p.local_count, 1);
        assert!(matches!(p.code.last(), Some(Op::Halt)));
    }
    #[test]
    fn rejects_unknown_variable() {
        assert!(compile("fn main() { print(nope); }").is_err());
    }
}
