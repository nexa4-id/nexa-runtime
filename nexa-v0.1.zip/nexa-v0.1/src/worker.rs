//! Small reusable worker pool. Tasks are queued and workers are reused.
use std::{collections::VecDeque, sync::{Arc, Condvar, Mutex, mpsc}, thread::{self, JoinHandle}};

type Task = Box<dyn FnOnce() + Send + 'static>;
struct State { queue: VecDeque<Task>, shutdown: bool }
struct Shared { state: Mutex<State>, ready: Condvar }

pub struct WorkerPool { shared: Arc<Shared>, threads: Vec<JoinHandle<()>> }

impl WorkerPool {
    pub fn new(worker_count: usize) -> Self {
        let count = worker_count.max(1);
        let shared = Arc::new(Shared { state: Mutex::new(State { queue: VecDeque::new(), shutdown: false }), ready: Condvar::new() });
        let mut threads = Vec::with_capacity(count);
        for _ in 0..count {
            let worker_shared = Arc::clone(&shared);
            threads.push(thread::spawn(move || loop {
                let task = {
                    let mut state = worker_shared.state.lock().expect("worker queue mutex poisoned");
                    while state.queue.is_empty() && !state.shutdown {
                        state = worker_shared.ready.wait(state).expect("worker queue mutex poisoned");
                    }
                    if state.shutdown && state.queue.is_empty() { return; }
                    state.queue.pop_front()
                };
                if let Some(task) = task { task(); }
            }));
        }
        Self { shared, threads }
    }

    pub fn submit<F, T>(&self, job: F) -> mpsc::Receiver<T>
    where F: FnOnce() -> T + Send + 'static, T: Send + 'static {
        let (tx, rx) = mpsc::channel();
        let task: Task = Box::new(move || { let result = job(); let _ = tx.send(result); });
        let mut state = self.shared.state.lock().expect("worker queue mutex poisoned");
        if state.shutdown { panic!("cannot submit to a stopped Nexa worker pool"); }
        state.queue.push_back(task);
        drop(state);
        self.shared.ready.notify_one();
        rx
    }

    pub fn size(&self) -> usize { self.threads.len() }
}

impl Drop for WorkerPool {
    fn drop(&mut self) {
        { let mut state = self.shared.state.lock().expect("worker queue mutex poisoned"); state.shutdown = true; }
        self.shared.ready.notify_all();
        for handle in self.threads.drain(..) { let _ = handle.join(); }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn executes_many_jobs_on_reusable_pool() {
        let pool = WorkerPool::new(4);
        let results: Vec<_> = (0..100).map(|n| pool.submit(move || n * n)).collect();
        let total: usize = results.into_iter().map(|r| r.recv().unwrap()).sum();
        assert_eq!(total, (0..100).map(|n| n * n).sum());
        assert_eq!(pool.size(), 4);
    }
    #[test]
    fn clamps_zero_workers_to_one() { assert_eq!(WorkerPool::new(0).size(), 1); }
}
