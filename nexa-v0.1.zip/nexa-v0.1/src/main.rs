mod compiler;
mod lexer;
mod vm;
mod worker;

use std::{env, fs, process};

fn usage() {
    eprintln!("Nexa v0.1.0\nUsage: nexa run <file.nx>\n       nexa help");
}

fn main() {
    let args: Vec<String> = env::args().collect();
    match args.get(1).map(String::as_str) {
        Some("run") => {
            let Some(path) = args.get(2) else {
                usage();
                process::exit(2);
            };
            let source = match fs::read_to_string(path) {
                Ok(s) => s,
                Err(e) => {
                    eprintln!("nexa: cannot read '{path}': {e}");
                    process::exit(1);
                }
            };
            let program = match compiler::compile(&source) {
                Ok(p) => p,
                Err(e) => {
                    eprintln!("compile error: {e}");
                    process::exit(1);
                }
            };
            if let Err(e) = vm::execute(&program) {
                eprintln!("runtime error: {e}");
                process::exit(1);
            }
        }
        Some("help") | None => usage(),
        Some(other) => {
            eprintln!("unknown command: {other}");
            usage();
            process::exit(2);
        }
    }
}
