# Nexa v0.1.0

Nexa is an experimental Rust-inspired language with a custom bytecode compiler and stack-based virtual machine. This first milestone supports integer arithmetic, local `let` bindings, `print`, and a reusable worker pool library.

## Requirements

- Rust stable toolchain (install from https://rustup.rs)
- Cargo (included with Rust)

## Build

```sh
cargo build --release
```

## Run the example

```sh
cargo run --release -- run examples/hello.nx
```

Expected output:

```text
52
```

## Run tests

```sh
cargo test
```

The tests cover tokenization, compilation, arithmetic execution, division-by-zero handling, and concurrent task execution in the worker pool.

## Current language subset

```rust
fn main() {
    let x: i64 = 10;
    let y = 20;
    print(x + y * 2);
}
```

Supported: `fn main()`, `let`, optional `: i64`, integer literals, variable reads, parentheses, unary minus, `+`, `-`, `*`, `/`, `print(expr);`, and `//` comments.

Not yet supported: functions other than `main`, strings, booleans, conditionals, loops, user-defined functions, async/await, modules, networking, and package management.

## Worker pool API (Rust host-side prototype)

The worker pool is currently an internal Rust runtime module, not yet exposed to `.nx` programs. It reuses a fixed number of OS threads and queues submitted jobs. Example integration and language-level worker syntax will arrive in the next milestone.

## Project layout

- `src/lexer.rs` — tokenizer
- `src/compiler.rs` — parser and bytecode compiler
- `src/vm.rs` — stack virtual machine
- `src/worker.rs` — reusable worker pool
- `src/main.rs` — command-line interface
- `examples/hello.nx` — sample program

## Design notes

This is an educational/experimental baseline, not yet a production replacement for Node.js. Performance claims require repeatable benchmarks against equivalent workloads. The first worker pool uses a shared FIFO queue; work-stealing is a later optimization, not a feature claimed by v0.1.
